
    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl+'';f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-PPB9NV');
  


    (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl+'';f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-KHJ2NGN');
  

(()=>{function p(t,n,r,o,e,i,f,m){return{eventType:t,event:n,targetElement:r,eic:o,timeStamp:e,eia:i,eirp:f,eiack:m}}function u(t){let n=[],r=e=>{n.push(e)};return{c:t,q:n,et:[],etc:[],d:r,h:e=>{r(p(e.type,e,e.target,t,Date.now()))}}}function s(t,n,r){for(let o=0;o<n.length;o++){let e=n[o];(r?t.etc:t.et).push(e),t.c.addEventListener(e,t.h,r)}}function c(t,n,r,o,e=window){let i=u(t);e._ejsas||(e._ejsas={}),e._ejsas[n]=i,s(i,r),s(i,o,!0)}window.__jsaction_bootstrap=c;})();


window.__jsaction_bootstrap(document.body,"ng",["click","keydown"],["focus","blur"]);

{
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "@id": "6631873083-365847200-true",
  "name": "TOM-MAR MARCIN PŁUSA, TOMASZ ZBROJA SPÓŁKA CYWILNA ",
  "legalName": "TOM-MAR MARCIN PŁUSA, TOMASZ ZBROJA SPÓŁKA CYWILNA ",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "ul. Bugaj 5A",
    "postalCode": "26-130",
    "addressLocality": "Suchedniów",
    "addressCountry": "PL"
  },
  "review": [
    {
      "@type": "Review",
      "datePublished": "2023-08-03 09:31:41",
      "reviewBody": "Firma dziad. Po złożeniu zamówienia zero kontaktu. Ani be, ani me ani pocałuj mnie w d... towaru do tej pory nie ma.  Nawet nie raczy nikt się odezwać i przeprosić, choć wiadomości do nich były odczytywane.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 1
      },
      "author": {
        "@type": "Person",
        "name": "DSm"
      }
    },
    {
      "@type": "Review",
      "datePublished": "2023-01-09 18:47:10",
      "reviewBody": "Oddałam do naprawy laptop, robocza spartaczona, po po miesiącu laptop padł. Był wymieniony dysk /rzekomo był nowy, zapłaciłam 300 zl/ , ale wytrzymał tylko miesiąc. Zamieniono mi także baterie. Przed naprawą funkcjonowała 4,5 godz. po naprawie musiała być non stop pod ładowarką. Partactwo i straszne oszustwo klientów. Nie polecam.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 1
      },
      "author": {
        "@type": "Person",
        "name": "Keniucha"
      }
    }
  ],
  "telephone": "884293011",
  "email": "tommarpz@interia.eu",
  "taxID": "6631873083",
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": 1,
    "ratingCount": 2,
    "bestRating": 5,
    "worstRating": 1
  }
}

{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "item": {
        "@id": "null/pl/firmy/it-i-telekomunikacja",
        "name": "IT i telekomunikacja"
      }
    },
    {
      "@type": "ListItem",
      "position": 2,
      "item": {
        "@id": "null/pl/firmy/it-i-telekomunikacja/uslugi-it",
        "name": "Usługi IT"
      }
    },
    {
      "@type": "ListItem",
      "position": 3,
      "item": {
        "@id": "null/pl/firmy/it-i-telekomunikacja/uslugi-it/serwis-i-naprawa-sprzetu-it",
        "name": "Serwis i naprawa sprzętu IT"
      }
    },
    {
      "@type": "ListItem",
      "position": 4,
      "item": {}
    }
  ]
}


    document.getElementById('rv-h5-f92c6933d4').onload = true ? function () {
        var i = document.createElement('IMG');
        i.src = 'https://media.ingdlabiznesu.pl/contentbase/hub/lg.php?udb=80&udbcampaignid=9&zoneid=1&source=test-aleo&loc=https%3A%2F%2Faleo.com%2Fpl%2Ffirma%2Ftom-mar-marcin-plusa%2C-tomasz-zbroja-spolka-cywilnasuchedniow&cb=f92c6933d4';
    } : null;


{
  "@type": "AggregateRating",
  "ratingValue": 1,
  "ratingCount": 2,
  "bestRating": 5,
  "worstRating": 1
}

{"621720934":{"b":{"identification":{"nip":"6631873083","regon":"365847200","isCompany":true,"id":"6631873083-365847200-true"},"registryData":{"name":"TOM-MAR MARCIN PŁUSA, TOMASZ ZBROJA SPÓŁKA CYWILNA ","siteUrl":"","phoneNumber":"884293011","email":"tommarpz@interia.eu","bankrupt":false,"legalFormCode":"CIVIL_LAW_PARTNERSHIP","publicBenefitOrg":false,"status":"ACTIVE","use2025PkdStandard":false,"registryAddDate":"2016-11-14","registry":"REGON","registrationAuthority":"","pkdCodes":[{"code":"95.11.Z","main":true},{"code":"26.12.Z","main":false},{"code":"33.12.Z","main":false},{"code":"33.13.Z","main":false},{"code":"33.14.Z","main":false},{"code":"33.20.Z","main":false},{"code":"43.21.Z","main":false}]},"addresses":[{"addressType":"MAIN","address":"ul. Bugaj 5A","zipCode":"26-130","city":"Suchedniów","countryCode":"PL"}],"seo":{"indexNoFollow":false},"bankAccounts":{"vatTaxPayerStatus":"ACTIVE","updateTs":"2025-07-09 11:24:40","bankAccounts":[{"accountNumber":"PL14  105 0 14 61 1 000  0092  347 3 83 01","bank":"ING"}]},"categories":[{"paths":[{"name":"IT i telekomunikacja","path":"it-i-telekomunikacja"},{"name":"Usługi IT","path":"uslugi-it"},{"name":"Serwis i naprawa sprzętu IT","path":"serwis-i-naprawa-sprzetu-it"}],"main":true},{"paths":[{"name":"IT i telekomunikacja","path":"it-i-telekomunikacja"},{"name":"Sprzęt IT, urządzenia peryferyjne","path":"sprzet-it-urzadzenia-peryferyjne"},{"name":"Obwody drukowane","path":"obwody-drukowane"}],"main":false},{"paths":[{"name":"Maszyny i utrzymanie ciągłości produkcji","path":"maszyny-i-utrzymanie-ciaglosci-produkcji"},{"name":"Serwis maszyn, urządzeń i części zamiennych","path":"serwis-maszyn-urzadzen-i-czesci-zamiennych"},{"name":"Maszyn","path":"maszyn"}],"main":false},{"paths":[{"name":"Maszyny i utrzymanie ciągłości produkcji","path":"maszyny-i-utrzymanie-ciaglosci-produkcji"},{"name":"Serwis maszyn, urządzeń i części zamiennych","path":"serwis-maszyn-urzadzen-i-czesci-zamiennych"},{"name":"Elektronicznych i optycznych","path":"elektronicznych-i-optycznych"}],"main":false},{"paths":[{"name":"Maszyny i utrzymanie ciągłości produkcji","path":"maszyny-i-utrzymanie-ciaglosci-produkcji"},{"name":"Serwis maszyn, urządzeń i części zamiennych","path":"serwis-maszyn-urzadzen-i-czesci-zamiennych"},{"name":"Elektrycznych","path":"elektrycznych"}],"main":false},{"paths":[{"name":"Maszyny i utrzymanie ciągłości produkcji","path":"maszyny-i-utrzymanie-ciaglosci-produkcji"},{"name":"Serwis maszyn, urządzeń i części zamiennych","path":"serwis-maszyn-urzadzen-i-czesci-zamiennych"},{"name":"Instalowanie maszyn","path":"instalowanie-maszyn"}],"main":false},{"paths":[{"name":"Budownictwo, usługi i materiały budowlane","path":"budownictwo-uslugi-i-materialy-budowlane"},{"name":"Budowanie instalacji","path":"budowanie-instalacji"},{"name":"Instalacje elektryczne","path":"instalacje-elektryczne"}],"main":false}],"financialGrants":[]},"h":{},"s":200,"st":"OK","u":"/api/v2/companies","rt":"json"},"2497633000":{"b":{"averageRating":1,"numberOfOpinions":2,"ratesCount":[{"count":2,"rate":1}]},"h":{},"s":200,"st":"OK","u":"/api/public/companies/6631873083-365847200-true/opinions/average","rt":"json"},"3678332245":{"b":{"edges":[],"personalNodes":[],"companyNodes":[]},"h":{},"s":200,"st":"OK","u":"/api/v2/companies/6631873083-365847200-true/relations","rt":"json"},"3779513825":{"b":[],"h":{},"s":200,"st":"OK","u":"/api/v2/cms/firmove/category-articles","rt":"json"},"3897897228":{"b":[{"opinion":"Firma dziad. Po złożeniu zamówienia zero kontaktu. Ani be, ani me ani pocałuj mnie w d... towaru do tej pory nie ma.  Nawet nie raczy nikt się odezwać i przeprosić, choć wiadomości do nich były odczytywane.","rate":1,"createTs":"2023-08-03 09:31:41","reviewerFullName":"DSm","reviewer":{"fullName":"DSm"}},{"opinion":"Oddałam do naprawy laptop, robocza spartaczona, po po miesiącu laptop padł. Był wymieniony dysk /rzekomo był nowy, zapłaciłam 300 zl/ , ale wytrzymał tylko miesiąc. Zamieniono mi także baterie. Przed naprawą funkcjonowała 4,5 godz. po naprawie musiała być non stop pod ładowarką. Partactwo i straszne oszustwo klientów. Nie polecam.","rate":1,"createTs":"2023-01-09 18:47:10","reviewerFullName":"Keniucha","reviewer":{"fullName":"Keniucha"}}],"h":{},"s":200,"st":"OK","u":"/api/public/companies/6631873083-365847200-true/opinions","rt":"json"},"english-version-current-path":"/int/company/tom-mar-marcin-plusa,-tomasz-zbroja-spolka-cywilnasuchedniow","__nghData__":[{"t":{"2":"t2"},"c":{"2":[]}},{"t":{"5":"t0","6":"t1","10":"t3"},"c":{"5":[],"6":[{"i":"t1","r":1}],"10":[{"i":"t3","r":1,"t":{"4":"t4"},"c":{"4":[]}}]}},{"t":{"2":"t5"},"c":{"2":[]}},{"d":[1]},{},{"t":{"0":"t8","2":"t9"},"c":{"0":[{"i":"t8","r":1}],"2":[{"i":"t9","r":1}]}},{"t":{"1":"t23","2":"t32","3":"t26"},"c":{"1":[{"i":"t23","r":4,"e":{"0":3},"t":{"1":"t24","2":"t31"},"c":{"1":[{"i":"t24","r":1,"t":{"1":"t25"},"c":{"1":[{"i":"t26","r":6,"t":{"0":"t27","1":"t28","2":"t29","4":"t30"},"c":{"0":[{"i":"t27","r":1}],"1":[{"i":"t28","r":1}],"2":[],"4":[]}}]}}],"2":[]}}],"2":[],"3":[]}},{"t":{"0":"t10"},"c":{"0":[{"i":"t10","r":1,"t":{"2":"t11","5":"t12","6":"t33","7":"t34"},"c":{"2":[],"5":[{"i":"t12","r":47,"t":{"0":"t13"},"c":{"0":[{"i":"t13","r":21,"t":{"0":"t14","1":"t15","2":"t20"},"c":{"0":[],"1":[{"i":"t15","r":2,"c":{"0":[],"1":[{"i":"t16","r":4,"e":{"0":3},"t":{"1":"t17","2":"t18"},"c":{"1":[{"i":"t17","r":1}],"2":[]}}],"2":[]},"t":{"1":"t16","2":"t19"}}],"2":[{"i":"t20","r":4,"t":{"0":"t21","1":"t22"},"c":{"0":[],"1":[{"i":"t22","r":2,"c":{"0":[]}}]},"x":4}]}},{"i":"t13","r":25,"t":{"0":"t14","1":"t15","2":"t20"},"c":{"0":[],"1":[{"i":"t15","r":2,"c":{"0":[],"1":[{"i":"t16","r":4,"e":{"0":3},"t":{"1":"t17","2":"t18"},"c":{"1":[{"i":"t17","r":1}],"2":[]}}],"2":[]},"t":{"1":"t16","2":"t19"}}],"2":[{"i":"t20","r":4,"t":{"0":"t21","1":"t22"},"c":{"0":[],"1":[{"i":"t22","r":2,"c":{"0":[]}}]},"x":5}]}}]}}],"6":[],"7":[]}}]}},{"t":{"0":"t38","1":"t41","2":"t39"},"c":{"0":[{"i":"t39","r":1,"t":{"0":"t40"},"c":{"0":[]}}],"1":[],"2":[]}},{"t":{"0":"t45","1":"t46"},"c":{"0":[{"i":"t46","r":1,"t":{"0":"t47"},"c":{"0":[]}}],"1":[]}},{"t":{"0":"t51","2":"t52"},"c":{"0":[{"i":"t52","r":1,"t":{"0":"t53"},"c":{"0":[]}}],"2":[]}},{"t":{"0":"t54"},"c":{"0":[]}},{"t":{"0":"t67"},"c":{"0":[{"i":"t67","r":1,"t":{"0":"t68"},"c":{"0":[]}}]}},{"t":{"0":"t35","2":"t55"},"c":{"0":[{"i":"t35","r":1,"t":{"1":"t36","3":"t37","6":"t42","7":"t44","8":"t48","9":"t49","10":"t50"},"c":{"1":[{"i":"t36","r":1}],"3":[],"6":[],"7":[{"i":"t44","r":1}],"8":[],"9":[],"10":[{"i":"t50","r":1}]}}],"2":[]}},{"t":{"0":"t56"},"c":{"0":[]}},{"t":{"2":"t57","7":"t58","10":"t64"},"c":{"2":[],"7":[{"i":"t58","r":2,"c":{"0":[],"2":[],"3":[],"4":[{"i":"t62","r":1,"t":{"1":"t63"},"c":{"1":[{"i":"t63","r":1}]}}]},"t":{"2":"t59","3":"t60","4":"t61"},"x":3}],"10":[]}},{"t":{"0":"t6","1":"t65"},"c":{"0":[{"i":"t6","r":3,"e":{"0":2},"t":{"2":"t7"},"c":{"2":[{"i":"t7","r":1}]}}],"1":[]}},{"c":{"3":[{"i":"c1230700670","r":1}],"5":[]},"t":{"5":"t66"}}]}

function getCookie(a){return(a=document.cookie.match("(^|;) ?"+a+"\x3d([^;]*)(;|$)"))?a[2]:null}function setCookie(a,c,d){var b=new Date;b.setTime(b.getTime()+864E5*d);document.cookie=a+"\x3d"+c+";path\x3d/;expires\x3d"+b.toGMTString()}function deleteCookie(a){setCookie(a,"",-1)};

document.querySelector("#search_form_phrase, #searchbox-input").addEventListener("keyup",function(a){13==a.keyCode&&(analyticsDataLayer("Company Profile","Searcher","Input insert"),eventGA4("search",1),hj("tagRecording",["Searcher Used"]))});

var placementVariants=["luxmed","esg","quiz-game"];setTimeout(function(){dataLayer.push({event:"firmove-variant","variation-name":placementVariants[Math.floor(Math.random()*placementVariants.length)]})},500);

$(document).ready(function(){generateTooltips()});
var data=[{tekst:'Forma prawna wp\u0142ywa na wiele aspekt\u00f3w Twojej dzia\u0142alno\u015bci. Wejd\u017a na \x3ca href\x3d"https://firmove.pl/aktualnosci/biznes/zalozenie-firmy/formy-prawne-dzialalnosci-gospodarczej--rodzaje?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial"\x3efirmove.pl\x3c/a\x3e i dowiedz si\u0119 wi\u0119cej',typ:"A",link:"https://firmove.pl/aktualnosci/biznes/zalozenie-firmy/formy-prawne-dzialalnosci-gospodarczej--rodzaje?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial",placement:"#company-registry-data-section \x3e div \x3e div.registry-details.mt-8.ng-star-inserted \x3e div:nth-child(3) \x3e div \x3e div",
obrazek:"",tytul:"",CTA:""},{tekst:"Dowiedz si\u0119, jak skutecznie reklamowa\u0107 firm\u0119 w internecie, z wykorzystaniem Social Media i Google Ads",typ:"E",link:"https://firmove.pl/przewodniki/promocja-firmy-w-internecie?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial",placement:"#company-info-section \x3e app-company-contact \x3e div \x3e div.socials.ng-star-inserted \x3e h3",obrazek:"https://firmove.pl/_fileserver/time20230809083725/item/webp/1509993?size\x3dsmall",
tytul:"",CTA:"Sprawd\u017a"},{tekst:"Chcesz zbudowa\u0107 mocn\u0105 mark\u0119 w internecie? Skorzystaj z naszych podpowiedzi!",typ:"G",link:"https://firmove.pl/przewodniki/start-firmy-w-internecie?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial",placement:"#company-info-section \x3e app-company-contact \x3e div \x3e div.site.ng-star-inserted \x3e h3",obrazek:"https://firmove.pl/_fileserver/time20230104105550/item/webp/1510310?size\x3dsmall",tytul:"",CTA:"Sprawd\u017a"},
{tekst:"Z nasz\u0105 instrukcj\u0105 zmienisz lub dopiszesz kod PKD przez internet",typ:"G",link:"https://firmove.pl/aktualnosci/biznes/prowadzenie-firmy/zmiana-kodow-pkd-online?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial",placement:"#company-registry-data-section \x3e div \x3e div.pkd-codes.ng-star-inserted.questo-paywall \x3e h3",obrazek:"",tytul:"",CTA:"Przejd\u017a do instrukcji"},{tekst:"Zobacz, czy warto by\u0107 VAT-owcem",typ:"D",link:"https://firmove.pl/aktualnosci/finanse/podatki/czynny-podatnik-vat-co-sie-z-tym-wiaze?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial",
placement:"#company-registry-data-section \x3e app-bank-accounts \x3e div.vat-status-section.ng-star-inserted \x3e div \x3e div.py-2 \x3e span",obrazek:"https://firmove.pl/_fileserver/time20221220205129/item/webp/1509938?size\x3dsmall",tytul:"Czynny podatnik VAT \u2013 czyli kto?",CTA:""},{tekst:'Nie wiesz, czym jest bia\u0142a lista podatnik\u00f3w VAT? Odpowied\u017a znajdziesz na \x3ca href\x3d"https://firmove.pl/aktualnosci/biznes/prowadzenie-firmy/biala-lista-podatnikow-vat?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial"\x3efirmove.pl\x3c/a\x3e',
typ:"A",link:"https://firmove.pl/aktualnosci/biznes/prowadzenie-firmy/biala-lista-podatnikow-vat?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial",placement:"#company-registry-data-section \x3e app-bank-accounts \x3e div.bank-accounts-section.ng-star-inserted \x3e div",obrazek:"",tytul:"",CTA:""},{tekst:"Szukasz sposob\u00f3w na dofinansowanie swojego biznesu? Dowiedz si\u0119 wi\u0119cej o funduszach europejskich",typ:"D",link:"https://firmove.pl/przewodniki/finansowanie/fundusze-europejskie?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial",
placement:"app-registry-data-section .section-title",obrazek:"https://firmove.pl/_fileserver/time20221208203430/item/webp/1509780?size\x3dsmall",tytul:"",CTA:""},{tekst:'Kiedy i jak przeprowadzi\u0107 ocen\u0119 kondycji finansowej firmy? Sprawd\u017a na \x3ca href\x3d"https://firmove.pl/przewodniki/ryzyko-i-ubezpieczenia/ocena-kondycji-firmy?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial"\x3efirmove.pl\x3c/a\x3e',typ:"A",link:"https://firmove.pl/przewodniki/ryzyko-i-ubezpieczenia/ocena-kondycji-firmy?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial",
placement:"#company-financial-indicators-section \x3e h2",obrazek:"",tytul:"",CTA:""},{tekst:'Czym r\u00f3\u017cni si\u0119 przych\u00f3d od dochodu? Przeczytaj na \x3ca href\x3d"https://firmove.pl/aktualnosci/biznes/prowadzenie-firmy/dochod-a-przychod-roznice?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial"\x3efirmove.pl\x3c/a\x3e',typ:"A",link:"https://firmove.pl/aktualnosci/biznes/prowadzenie-firmy/dochod-a-przychod-roznice?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial",
placement:"#company-financial-indicators-section \x3e div.flex.mb-8.ng-star-inserted \x3e div:nth-child(1) \x3e div.financial-data__label",obrazek:"",tytul:"",CTA:""},{tekst:"Rachunek zysk\u00f3w i strat to cz\u0119\u015b\u0107 sprawozdania finansowego.",typ:"G",link:"https://firmove.pl/aktualnosci/finanse/ksiegowosc/rachunek-zyskow-i-strat--co-to-jest-i-kto-go-sporzadza?utm_source\x3daleo.com\x26utm_medium\x3dtooltip\x26utm_campaign\x3dtutorial",placement:"#company-financial-indicators-section \x3e div.flex.mb-8.ng-star-inserted \x3e div:nth-child(2) \x3e div.financial-data__label",
obrazek:"",tytul:"",CTA:"Zobacz, z czego si\u0119 sk\u0142ada"}];
function generateTooltips(){function k(b){var g=document.createElement("div");g.classList.add("tooltip-container","variant-"+b.typ);var h=document.createElement("span");h.classList.add("tooltip-icon");var c=document.createElement("div");c.classList.add("tooltip");c.style.display="none";var d=document.createElement("div");d.classList.add("tooltip-header");var e=document.createElement("span");e.classList.add("tooltip-powered");if(["A","B","G"].indexOf(b.typ)!==-1){var a=document.createElement("img");
a.src="https://aleo.com/_fileserver/item/16615/firmove-logo.svg";a.alt="logo";e.appendChild(a)}else e.classList.add("tooltip-image"),a=document.createElement("img"),a.src=b.obrazek,a.alt="Unique Image",e.appendChild(a);a=document.createElement("div");a.classList.add("tooltip-title");if(b.typ==="D"||b.typ==="F"){var f=document.createElement("a");f.href=b.link;f.classList.add("tooltip-link");f.innerText=b.tytul;a.appendChild(f)}else a.innerText=b.tytul;d.appendChild(a);d.appendChild(e);c.appendChild(d);
d=document.createElement("div");d.classList.add("tooltip-body");b.typ==="D"||b.typ==="F"?(a=document.createElement("a"),a.href=b.link,a.classList.add("tooltip-link"),a.innerHTML=b.tekst,d.innerHTML="",d.appendChild(a)):d.innerHTML=b.tekst;e=document.createElement("div");e.classList.add("tooltip-footer");a=document.createElement("a");a.href=b.link;a.classList.add("tooltip-link");a.innerText=b.CTA||"Zobacz profil";e.appendChild(a);f=document.createElement("div");f.classList.add("tooltip-arrow");g.appendChild(h);
g.appendChild(c);b.typ==="E"?(h=document.createElement("div"),h.classList.add("tooltip-image"),a=document.createElement("img"),a.src=b.obrazek,a.alt="Unique Image",h.appendChild(a),a=document.createElement("div"),a.classList.add("tooltip-content"),a.appendChild(d),a.appendChild(e),c.innerHTML="",c.appendChild(h),c.appendChild(a)):(c.appendChild(d),["A","B","D"].indexOf(b.typ)===-1&&c.appendChild(e));c.appendChild(f);["D","F"].indexOf(b.typ)!==-1&&(d=c.querySelector(".tooltip-header"),d.style.flexDirection=
"column-reverse");g.addEventListener("mouseenter",function(){c.style.display="block"});g.addEventListener("mouseleave",function(){c.style.display="none"});(b=document.querySelector(b.placement))&&b.appendChild(g)}data.forEach(function(b){k(b)})};

var firmoveSection=document.querySelector("section#firmove-articles");
if(firmoveSection)for(var articleLinks=firmoveSection.querySelectorAll(".article-body .article-title #profile-articles-referral"),i=0;i<articleLinks.length;i++){var currentHref=articleLinks[i].getAttribute("href"),articleContainer=articleLinks[i].closest(".featured-article");if(articleContainer){var headerLink=articleContainer.querySelector(".article-header #profile-articles-referral");headerLink&&headerLink.setAttribute("href",currentHref)}};

var html='\x3cstyle\x3e.hellobar{background-color:#e8f3fa;display:flex;align-items:center;justify-content:center;padding:10px 0;width:100%;position:relative;overflow:hidden;font-family:INGme,FS me,Helvetica,Arial,sans-serif; z-index:1}.hellobar-wrapper{position:relative;overflow:hidden;width:100%}.hellobar-content{display:flex;align-items:center;gap:10px;position:relative;width:auto;justify-content:center;transform:translateY(100%);transition:transform .5s ease-in-out}.hellobar-content.show{transform:translateY(0)}.hellobar-content img{max-height:55px}.hellobar-text{color:#333;font-size:16px;line-height:24px;font-weight:400;text-align:center}.hellobar-cta{background-color:#525199;color:#fff;text-decoration:none;padding:13px 16px;border-radius:5px;font-size:14px;line-height:16px;font-weight:700}.hellobar-cta:hover{background-color:#434080}\x3c/style\x3e\x3cdiv class\x3d"hellobar" id\x3d"hellobar"\x3e\x3cdiv class\x3d"hellobar-wrapper"\x3e\x3cdiv class\x3d"hellobar-content flex-col md:flex-row show" id\x3d"hellobar-content"\x3e\x3cimg id\x3d"hellobar-image" src\x3d"" alt\x3d"Ikona"\x3e\x3cspan id\x3d"hellobar-text" class\x3d"hellobar-text"\x3e\x3c/span\x3e\x3ca id\x3d"hellobar-cta" href\x3d"#" class\x3d"hellobar-cta"\x3e\x3c/a\x3e\x3c/div\x3e\x3cbutton class\x3d"close_hellobar" aria-label\x3d"Close" onclick\x3d"closeHelloBar()" style\x3d"display:-webkit-box;position:absolute;top:10px;right:10px;color:#51499e;font-size:24px"\x3e\u00d7\x3c/button\x3e\x3c/div\x3e\x3c/div\x3e',
hellobarItems=[{id:"luxmed",image:"https://aleo.com/_fileserver/item/17046/luxmed.png",text:"Zadbaj o zdrowie! Skorzystaj ze specjalnej oferty pakiet\u00f3w medycznych dla firm",ctaText:"Sprawdzam",ctaLink:"https://firmove.pl/niezbednik/pakiety-medyczne?utm_source\x3daleo.com\x26utm_medium\x3dbanner\x26utm_campaign\x3dhellobar"},{id:"CSRD_1",image:"https://aleo.com/_fileserver/item/17045/csrd.png",text:"W\u0142asna firma chodzi Ci po g\u0142owie? Za\u0142\u00f3\u017c j\u0105 ze wsparciem ksi\u0119gowego od ING",
ctaText:"Sprawd\u017a",ctaLink:"https://firmove.pl/niezbednik/zaloz-firme-z-ksiegowym?utm_source\x3daleo.com\x26utm_medium\x3dbanner\x26utm_campaign\x3dhellobar"},{id:"CSRD_2",image:"https://aleo.com/_fileserver/item/17044/csrd_phone.png",text:"My\u015blisz o w\u0142asnej firmie? Za\u0142\u00f3\u017c j\u0105 ze wsparciem ksi\u0119gowego od ING",ctaText:"Dowiedz si\u0119 wi\u0119cej",ctaLink:"https://firmove.pl/niezbednik/zaloz-firme-z-ksiegowym?utm_source\x3daleo.com\x26utm_medium\x3dbanner\x26utm_campaign\x3dhellobar"},
{id:"ebooks",image:"https://aleo.com/_fileserver/item/17048/ebooki.png",text:"Zapisz si\u0119 na newsletter i zgarnij darmowe e-book!",ctaText:"Sprawdzam",ctaLink:"https://firmove.pl/newsletter?utm_source\x3daleo.com\x26utm_medium\x3dbanner\x26utm_campaign\x3dhellobar"},{id:"ESG",image:"https://aleo.com/_fileserver/item/17043/esg.png",text:"Wzmacniaj konkurencyjno\u015b\u0107 klimatyczn\u0105 swojej firmy z pomoc\u0105 kalkulatora \u015bladu w\u0119glowego",ctaText:"Dowiedz si\u0119\u00a0wi\u0119cej",
ctaLink:"https://firmove.pl/kalkulatory/kalkulator-sladu-weglowego?utm_source\x3daleo.com\x26utm_medium\x3dbanner\x26utm_campaign\x3dhellobar"}],rotationType="random",rotationInterval=5E3,index=rotationType==="random"?Math.floor(Math.random()*hellobarItems.length):0;
function updateHellobar(){var b=document.getElementById("hellobar-content");b.classList.remove("show");setTimeout(function(){rotationType==="random"&&(index=Math.floor(Math.random()*hellobarItems.length));var a=hellobarItems[index];document.querySelector("#hellobar-content \x3e a").id="hellobar-"+a.id;document.getElementById("hellobar-image").src=a.image;document.getElementById("hellobar-text").innerHTML=a.text;document.querySelector(".hellobar-cta").textContent=a.ctaText;document.querySelector(".hellobar-cta").href=
a.ctaLink;b.classList.add("show");rotationType==="sequential"&&(index=(index+1)%hellobarItems.length)},300)}getCookie("HBisClosed")!=="true"&&document.querySelector("body").insertAdjacentHTML("afterbegin",html);updateHellobar();rotationType==="sequential"&&setInterval(updateHellobar,rotationInterval);function closeHelloBar(){document.querySelector("#hellobar").remove();setCookie("HBisClosed",!0,14)};

var notification_content='\x3cdiv class\x3d"notification-bell-container"\x3e\x3ca class\x3d"notification-bell" style\x3d"cursor: pointer;position:relative;display:inline-block;font-size:20px;width:24px"\x3e\x3cimg src\x3d"https://aleo.com/_fileserver/item/16509/bell.png" style\x3d"width:24px!important;height:24px"\x3e\x3cspan class\x3d"bell__badge" style\x3d"position:absolute;top:0;right:0;background-color:#ff6200;color:#fff;border-radius:95px;padding:0 7px;font-size:8px;border:1px solid #fff;right:-10px;top:-8px"\x3e\x3c/span\x3e\x3c/a\x3e \x3cdiv style\x3d"border: 1px solid #271e98; background: var(--primary-white,#fff); -webkit-box-shadow: 4px 16px 15px -5px rgba(66, 68, 90, 0.45);-moz-box-shadow: 4px 16px 15px -5px rgba(66, 68, 90, 0.45);box-shadow: 4px 16px 15px -5px rgba(66, 68, 90, 0.45); top: 50px; width: 401px; padding: 8px 16px; left: 1051px; position: absolute; gap: 16px; border-radius: 8px; z-index: 1;white-space: normal;" class\x3d"notification-bell-messages hide"\x3e \x3cdiv style\x3d"display:flex;justify-content:space-between;align-items:center;padding:8px 0"\x3e\x3cspan style\x3d"font-size: 11px; font-family: INGme,Roboto; font-style: normal; font-weight: 700; line-height: 16px; letter-spacing: .11px; text-transform: uppercase; color: #838395; display: flex;align-items: center;"\x3ePowiadomienia\x3cspan class\x3d"notifications-counter hide" style\x3d"color: #FFF; text-align: center; font-size: 11px; font-family: INGMe, Roboto; font-style: normal; font-weight: 700; line-height: 20px; letter-spacing: 0.11px; background: #51499E; padding: 0 4px; border-radius: 2px; margin-left: 5px;"\x3e1\x3cspan\x3e\x3c/span\x3e\x3c/span\x3e\x3c/span\x3e\x3cspan class\x3d"notification-bell-markAsRead" onclick\x3d"notificationIsReaded()" style\x3d"display:flex;font-size:12px;font-family:INGme,Roboto;font-style:normal;font-weight:400;line-height:16px;text-decoration-line:underline;color:#271e87;cursor: pointer;"\x3eOznacz jako przeczytane\x3c/span\x3e\x3c/div\x3e\x3ca id\x3d"notification-bell" href\x3d"https://firmove.pl/?utm_source\x3daleo.com\x26utm_medium\x3dlink\x26utm_campaign\x3dnotifications-bell" class\x3d"notification-bell-link"\x3e \x3cdiv style\x3d"display:flex;justify-content:space-between;align-items:start;margin-top:8px;gap:12px"\x3e\x3cimg src\x3d"https://aleo.com/_fileserver/item/16510/avatar.png"\x3e \x3cdiv style\x3d"display:flex;flex-direction:column;margin-bottom:16px"\x3e\x3cspan style\x3d"font-size:14px;font-family:INGme,Roboto;font-style:normal;font-weight:700;line-height:20px"\x3eW\u0142asna firma chodzi Ci po g\u0142owie?\x3c/span\x3e\x3cspan style\x3d"color:#525261;font-size:12px;font-family:INGme,Roboto;font-style:normal;font-weight:400;line-height:16px"\x3eMamy dla Ciebie serwis, kt\u00f3ry pomo\u017ce Ci dobrze wystartowa\u0107! Znajdziesz tam eksperckie biznesowe tre\u015bci i bezp\u0142atne wsparcie w rejestracji firmy. \x3cspan style\x3d"color: #271E87;text-decoration: underline;"\x3eWejd\u017a na Firmove.pl\x3c/span\x3e\x3c/span\x3e\x3c/div\x3e\x3c/div\x3e\x3c/a\x3e \x3c/div\x3e\x3c/div\x3e';
function runBellNotification(){if(window.innerWidth>768){$("app-user-actions-header-area").prepend(notification_content);getCookie("notification-bell-empty")!=="true"&&($(".bell__badge, .notifications-counter").text("1"),$(".bell__badge, .notifications-counter").removeClass("hide"));$(".notification-bell").on("click",function(){$(".notification-bell-messages").toggleClass("hide")});var b=".notification-bell";document.addEventListener("click",function(a){(a=a.target.closest(b))||$(".notification-bell-messages").hasClass("hide")||
$(".notification-bell-messages").addClass("hide")})}}var interval=setInterval(function(){getCookie()==null&&(runBellNotification(),clearInterval(interval))},500);function notificationIsReaded(){setCookie("notification-bell-empty",!0);$(".bell__badge, .notifications-counter").addClass("hide")};

var bannerContainer="",isMobile=window.innerWidth<768;bannerContainer=isMobile?'\x3cins data-udb-zoneid\x3d"4" data-udb-source\x3d"test-aleo" data-udb-id\x3d"9362ecd18473f2e3eca481e0845ac5f8" class\x3d"block md:hidden mb-8"\x3e\x3c/ins\x3e':'\x3cins data-udb-zoneid\x3d"1" data-udb-source\x3d"test-aleo" data-udb-id\x3d"9362ecd18473f2e3eca481e0845ac5f8" class\x3d"hidden md:block mb-8"\x3e\x3c/ins\x3e';document.querySelector("app-company-info-section").insertAdjacentHTML("afterbegin",bannerContainer);

window.dataLayer.push({event:"banner-initize"});

window.addEventListener("message",function(a){a.origin==="https://media.ingdlabiznesu.pl"&&a.data.type==="storageUpdate"&&a.data.key==="ingCampaignVisitor"&&(console.log("Zmieniona warto\u015b\u0107:",a.data.value),a=document.querySelector("ins iframe"),a=new URL(a.src),a=a.searchParams.get("clickTag")||a.searchParams.get("href"),a=(new URL(decodeURIComponent(a))).searchParams.get("udb"),window.dataLayer.push({event:"ing-banner-click",GA4_eventValue:a}),userengage("event.ing-campagin",{bannerId:a}))});

var quizQuestion=[{name:"odsetek-facebook",question:"Odsetek internaut\u00f3w korzystaj\u0105cych w Polsce z Facebooka wynosi w przybli\u017ceniu:",answers:[{answer:"49%",status:"invalid"},{answer:"90%",status:"valid"},{answer:"65%",status:"invalid"}],quizUrl:"https://firmove.pl/quizy/zarzadzanie-firma"},{name:"fraza-kluczowa",question:"Fraza kluczowa sk\u0142adaj\u0105ca si\u0119 z kilku s\u0142\u00f3w nosi nazw\u0119:",answers:[{answer:"long word",status:"invalid"},{answer:"long tail",status:"valid"},
{answer:"long tongue",status:"invalid"}],quizUrl:"https://firmove.pl/quizy/promocja-firmy-w-internecie"},{name:"skladka-obowiazkowa",question:"Obowi\u0105zkow\u0105 op\u0142at\u0105 do ZUS w ramach Ulgi na start jest sk\u0142adka:",answers:[{answer:"emerytalna",status:"invalid"},{answer:"zdrowotna",status:"valid"},{answer:"chorobowa",status:"invalid"}],quizUrl:"https://firmove.pl/quizy/kadry-i-place"},{name:"prog-podatkowy",question:"Od jakiej kwoty nalicza si\u0119 drugi pr\u00f3g podatkowy w 2024 roku?",
answers:[{answer:"80 000z\u0142",status:"invalid"},{answer:"120 000z\u0142",status:"valid"},{answer:"200 000z\u0142",status:"invalid"}],quizUrl:"https://firmove.pl/quizy/jak-zalozyc-firme"}],quizQuestionNo=Math.floor(Math.random()*quizQuestion.length);
function generateQuizQuestionTemplate(a){return a='\x3cstyle\x3e#firmove-quiz-container{background:#fff;border-radius:8px;border:1px solid #d5d5d5;display:flex;padding:20px;gap:20px}.quiz-button{border-radius:6px;background:#e8f3fa;padding:14px;font-size:14px;border:1px solid transparent;box-sizing:border-box}.answer-box{display:grid;gap:12px;grid-template-columns:repeat(4,minmax(0,1fr))}.quiz-button.disabled {pointer-events: none;cursor: default;background: #D9D9D9 !important;}.quiz-button.redirect{background:#525199;color:#fff;font-weight:700;text-align:center}.quiz-button.valid[selected]{border:1px solid #349651;background:#d6f0cd}.quiz-button.invalid[selected]{border:1px solid #d70000;background:#fbd0d0}@media (max-width:768px){#firmove-quiz-container{flex-direction:column}.answer-box{grid-template-columns:repeat(1,minmax(0,1fr))}}\x3c/style\x3e\x3cspan class\x3d"label"\x3eAutopromocja\x3c/span\x3e\x3cdiv id\x3d"firmove-quiz-container" class\x3d"mb-5 font-INGme"\x3e\x3cdiv style\x3d"align-items:center;display:flex;flex-direction:column"\x3e\x3cimg src\x3d"https://aleo.com/_fileserver/item/16615/firmove-logo.svg"\x3e\x3cimg src\x3d"https://aleo.com/_fileserver/item/16719/1510041.png"\x3e\x3c/div\x3e\x3cdiv style\x3d"display:flex;flex-direction:column;gap:15px"\x3e\x3cdiv class\x3d"question-text" style\x3d"display:flex;flex-direction:column;gap:10px"\x3e\x3cp class\x3d"text-4xl"\x3e\x3cstrong\x3eBiznes nie ma przed Tob\u0105 tajemnic?\x3c/strong\x3e\x3c/p\x3e\x3cp\x3eRozwi\u0105\u017c Quiz i przekonaj si\u0119, jaki jest poziom Twojej biznesowej wiedzy.\x3c/p\x3e\x3c/div\x3e\x3cdiv class\x3d"question-box" style\x3d"display:flex;flex-direction:column;gap:5px"\x3e\x3cspan style\x3d"color:#696969;font-weight:700;font-size:14px"\x3e'+a.question+
'\x3c/span\x3e\x3cdiv class\x3d"answer-box"\x3e\x3cbutton class\x3d"quiz-button '+a.answers[0].status+'"\x3e'+a.answers[0].answer+'\x3c/button\x3e\x3cbutton class\x3d"quiz-button '+a.answers[1].status+'"\x3e'+a.answers[1].answer+'\x3c/button\x3e\x3cbutton class\x3d"quiz-button '+a.answers[2].status+'"\x3e'+a.answers[2].answer+'\x3c/button\x3e\x3ca id\x3d"quiz-'+a.name+'" href\x3d"'+a.quizUrl+"?utm_source\x3daleo.com\x26utm_medium\x3dbanner\x26utm_campaign\x3dquiz-"+a.name+'" class\x3d"quiz-button redirect disabled" target\x3d"_blank"\x3ePodejmij wyzwanie\x3c/a\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e'}
$("#company-registry-data-section").after(generateQuizQuestionTemplate(quizQuestion[quizQuestionNo]));var buttons=document.querySelectorAll(".question-box button");buttons.forEach(function(a){a.addEventListener("click",function(){buttons.forEach(function(b){b.removeAttribute("selected");b.setAttribute("disabled","true")});this.setAttribute("selected","");document.querySelector(".quiz-button.redirect").classList.remove("disabled");buttons.forEach(function(b){b.setAttribute("disabled","true")})})});

!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","424147054704250");fbq("track","PageView");